# Files altered for anonymous review

Three kinds of change were made to the released archive so it could be
shipped for anonymous review: an author name was removed from its README,
and git commit ids were removed from its manifests. Nothing else was
touched, and no measurement, row or result was modified.

`checksums.sha256` was resealed afterwards so the archive's own
`tools/validate.py` still verifies every other file. The released digests
are recorded here so the untouched files can still be checked against the
public release, and so these edits can be audited after de-anonymisation.

| File | Change | Released SHA-256 | In this package |
|---|---|---|---|
| `README.md` | author name removed from the Citation section | `4911e072ebef142f416fd29d1b9b306414fe286f5f3dd0ed3be4bc33afa24109` | `fd76712b391ff88a1b9337940a65470a607fa3c8b22e7b79a7455ab4416ff223` |
| `evidence/harness_scaling_curve/study_manifest.json` | git commit id removed | `67537c6f0e23ca144a90cd7cf058b56765fe2d095c3d99354bff345f37ad5cf3` | `52f83fbfeef424964de981757d9422bc7d7fdbf4bf1cb30028d958b6de769f22` |
| `manifest.json` | git commit id removed | `7b828c84ade3eb3fb855042ddf9c1b270d1c20daa4de085131b82c8b1255385c` | `26bc7839ae3efa16331f492d621554b26a90b72b29d1f57f15f676086a8be305` |
