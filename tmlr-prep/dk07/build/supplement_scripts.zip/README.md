# Supplementary material

Anonymous supplement. Everything here runs offline with Python 3.9 or newer and
the standard library only: no third-party packages, no model API key, no network
access, no GPU, and no cost.

## What this reproduces

`analysis/recompute.py` recomputes the paper's reported numbers from the
released evidence rows and compares each against the value printed in the paper.
It reimplements the paper's definitions rather than calling the evidence
archive's own analysis script, so agreement is not an artifact of a shared
implementation.

`analysis/frontier_cumulative.py` is a corrected implementation of the
delegation frontier, which the published development scorer computes without
the cumulative lower-band condition the paper requires.
`analysis/test_frontier_cumulative.py` is its regression suite, including a
randomised check against the rule as stated in the benchmark's own policy file.

## Steps

```text
python3 analysis/recompute.py --dataset <path to the evidence archive>
python3 -m unittest -v analysis/test_frontier_cumulative.py
```

Expected output:

- the recomputation reports **52 of 53** reported values reproducing, plus
  **132 of 132** cells of the two per-seed tables and **17 of 17** protocol
  claims. The single discrepancy is a rounding slip in prose that the paper's
  own tables contradict.
- the test suite reports **15 tests, 8 passing and 7 skipped**, exit code 0. The
  seven skips compare against the published development scorers, which are not
  bundled (see below); they run if you set `AI_LEVEL_VERIFIERS` to a copy of
  that directory, and then all 15 pass.

## What is included, and what is not

**The evidence archive is not included here.** The steps above therefore cannot be run from this supplement alone: they require the archive named in the paper's data-availability section, which is distributed separately. This package does not claim anonymous reproducibility.

**The published development scorers are not bundled.** They belong to a release
that carries no licence, and no result in the paper depends on them. The tests
that compare the corrected frontier against the published one therefore skip
unless `AI_LEVEL_VERIFIERS` points at a copy.

Not included, and not available to us either:

- The scoring utility that produced the harness-curve figures. The paper names
  it; it is not in any released archive.
- The item generators, reference solvers and specification-key tests behind the
  item-family accuracies. The paper states that these are not released.
- Two of the three harness-scaling curves. Only one executor's episode rows were
  released; the other two curves appear in the paper's tables only.
- The record of one of the two library audits.

## Evidence classes

Reproduction means different things for different rows, and the recomputation
labels each one:

- **archived**: original observations, hash-matched to the study manifest.
- **reconstructed**: rows rebuilt from an aggregate log after the run. Agreement
  shows the reconstruction is consistent with the published table, not that the
  original run produced those rows.
- **published tables only**: no artifact; arithmetic consistency is all that can
  be checked.

## Which items here have their answers attached

No evaluation item corpus is included in this variant, so no answer material
ships with it. No credential, private answer key or evaluation salt is included.
