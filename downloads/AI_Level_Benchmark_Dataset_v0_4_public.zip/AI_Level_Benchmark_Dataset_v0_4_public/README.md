# AI-Level Benchmark Dataset v0.4

Public development dataset for **AI-Level Bench v0.4**, grounded in **Unified Intelligence Theory and the Artificial Intelligence Level v2.6**.

## Cumulative structure

The dataset distinguishes five measurement structures:

1. **Hard cumulative capability ladders:** `C`, `I`, `M`, `O`, positive `SA1-SAΩ`, and `U`.
2. **Cumulative diagnostic sub-ladder:** `GP0-GP5` (GUI Perception). GP is inside the GUI/screen domain of C but never promotes `C^GUI`, `C`, or `U`.
3. **Cumulative delegation frontier:** `DI` requires every lower `T` band at the same `H` ceiling and reliability `p`.
4. **Ordered non-cumulative axes:** `T` classifies task structure; `H` classifies human cognitive intervention.
5. **Cumulative engineering ladder:** `HG` is a strict mechanism-superset reference harness ladder, not an intelligence family.

`SA0` is a baseline category (absence of a reliable grounded self-model), so SA retention begins at `SA1`.

## GP law

`GP5 => GP4 => GP3 => GP2 => GP1 => GP0`

`A |= GP_g iff V_GP,g(A)=1 and K_GP,<g(A)=1`.

The cumulative GP result is diagnostic only. A native-image `C^GUI` form may declare a minimum GP prerequisite that can block that form, but GP evidence cannot earn C credit.

## Main files

- `cumulative_policy.json` - normative typed cumulative semantics
- `canonical_method_catalog.jsonl` - canonical method records including six GP cumulative methods
- `ai_level_bench_public_dev_combined.jsonl` - combined public forms
- `method_style_contract.json` - AI-Level-Method-1.0 plus cumulative semantics
- `gui_perception_lattice.json` - cumulative GP sub-ladder
- `coverage.csv` - method/public-form coverage
- `validation_report.json` - parse, schema, and cumulative-policy checks

## Certification boundary

This is public development material. Official certification requires protected anchors and fresh hidden witnesses under the same canonical laws.


## Complete level-by-level benchmark matrix (v0.4)
Every framework object now has an explicit level record in `level_benchmark_matrix.jsonl`. Each record names the testing benchmark, concrete witness, intervention, ordered procedure, control/ablation, external verifier, metrics, certification gate, lower-level retention and binding status. The catalog includes C0-CΩ, C^GUI_0-C^GUI_Ω, GP0-GP5, I0-IΩ, M0-MΩ, O0-OΩ, SA0-SAΩ, T0-TΩ, H0-H5, the DI frontier, HG0-HGΩ and U0-UΩ. Pointer-only I/M catalog rows were removed.
